// Keshan Money starter. Replace the Firebase config below with your own web app config.
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.5/firebase-app.js";
import {
  getAuth, GoogleAuthProvider, FacebookAuthProvider,
  signInWithPopup, signInWithRedirect, getRedirectResult,
  onAuthStateChanged, signOut
} from "https://www.gstatic.com/firebasejs/10.12.5/firebase-auth.js";

const firebaseConfig = {
  apiKey: "YOUR_FIREBASE_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  appId: "YOUR_FIREBASE_APP_ID"
};
const configured = !Object.values(firebaseConfig).some(v => v.startsWith("YOUR_"));
let auth = null;
if (configured) auth = getAuth(initializeApp(firebaseConfig));

const $ = id => document.getElementById(id);
const state = { demo: false, user: null, points: 0, claimedDay: "", activity: [] };
let toastTimer;
function toast(message) {
  $("toast").textContent = message;
  $("toast").classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => $("toast").classList.remove("show"), 3000);
}
function todayKey() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
}
function coinPop(target) {
  const rect = target.getBoundingClientRect();
  const el = document.createElement("span");
  el.className = "coin-pop"; el.textContent = "◉";
  el.style.left = `${rect.left + rect.width/2}px`; el.style.top = `${rect.top}px`;
  document.body.appendChild(el); setTimeout(() => el.remove(), 1100);
}
function addActivity(title, amount, icon="✦") {
  state.activity.unshift({title, amount, icon, time: new Date().toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"})});
  renderActivity();
}
function renderActivity() {
  const host = $("activity");
  if (!state.activity.length) {
    host.innerHTML = '<div class="empty-state">Your reward activity will appear here.</div>'; return;
  }
  host.innerHTML = state.activity.slice(0,5).map(a =>
    `<div class="activity-item"><div class="activity-dot">${a.icon}</div><div class="activity-copy"><b>${a.title}</b><span>${a.time}</span></div><span class="activity-points">${a.amount > 0 ? "+" : ""}${a.amount}</span></div>`
  ).join("");
}
function showDashboard(user, demo=false) {
  state.user = user; state.demo = demo;
  $("welcome").classList.add("hidden"); $("dashboard").classList.remove("hidden");
  $("logoutBtn").classList.remove("hidden");
  $("status").textContent = demo ? "DEMO MODE" : "SIGNED IN";
  $("userLabel").textContent = user?.displayName || user?.email || "Demo member";
  $("avatar").textContent = (user?.displayName || user?.email || "K").trim().charAt(0).toUpperCase();
  $("balance").textContent = state.points.toLocaleString();
  $("withdrawBtn").disabled = true;
}
function addPoints(amount, label, icon) {
  state.points += amount; $("balance").textContent = state.points.toLocaleString();
  addActivity(label, amount, icon); coinPop($("balance")); toast(`+${amount} demo points collected!`);
}
function startDemo() {
  state.points = 125; state.claimedDay = ""; state.activity = [];
  addActivity("Welcome bonus (sample)", 125, "✦");
  showDashboard({displayName:"Demo member"}, true);
  toast("Demo started. These points have no cash value.");
}
async function signIn(providerName) {
  if (!configured) {
    toast("Add your Firebase config in app.js first. Demo mode is available below."); return;
  }
  const provider = providerName === "google" ? new GoogleAuthProvider() : new FacebookAuthProvider();
  try {
    if (location.protocol === "file:") { toast("Publish or run on localhost to use login."); return; }
    if (/Android|iPhone|iPad|iPod/i.test(navigator.userAgent)) await signInWithRedirect(auth, provider);
    else await signInWithPopup(auth, provider);
  } catch (e) {
    console.error(e);
    toast(e.code === "auth/unauthorized-domain" ? "Add this website domain in Firebase Authentication settings." : "Login failed. Check provider settings and try again.");
  }
}
$("googleBtn").addEventListener("click", () => signIn("google"));
$("facebookBtn").addEventListener("click", () => signIn("facebook"));
$("demoBtn").addEventListener("click", startDemo);
$("logoutBtn").addEventListener("click", async () => {
  if (auth && !state.demo) await signOut(auth);
  state.user = null; state.demo = false; state.points = 0; state.activity = [];
  $("dashboard").classList.add("hidden"); $("welcome").classList.remove("hidden"); $("logoutBtn").classList.add("hidden");
  $("status").textContent = "DEMO MODE"; toast("Signed out.");
});
$("dailyBtn").addEventListener("click", () => {
  if (!state.demo) { toast("Daily reward backend is not connected yet."); return; }
  if (state.claimedDay === todayKey()) { toast("Today's demo bonus has already been claimed."); return; }
  state.claimedDay = todayKey(); addPoints(10, "Daily bonus (demo)", "✦");
});
$("taskBtn").addEventListener("click", () => {
  if (!state.demo) { toast("Task rewards need a verified server-side task system."); return; }
  addPoints(5, "Sample task completed", "✓");
});
$("refBtn").addEventListener("click", async () => {
  if (!state.demo) { toast("Referral tracking is not connected yet."); return; }
  const code = "KM-DEMO-125";
  try { await navigator.clipboard.writeText(`${location.href.split("#")[0]}?ref=${code}`); toast("Demo referral link copied."); }
  catch { toast(`Demo referral code: ${code}`); }
});
$("adsBtn").addEventListener("click", () => toast("No ad provider connected. Never reward clicks on ordinary ads."));
$("withdrawBtn").addEventListener("click", () => toast("Withdrawals are disabled until verified earnings and admin review are implemented."));

if (auth) {
  getRedirectResult(auth).catch(console.error);
  onAuthStateChanged(auth, user => {
    if (user) {
      state.points = 0; state.activity = [];
      showDashboard(user, false);
      toast("Signed in. Real reward balances are not connected in this starter.");
    } else if (!state.demo) {
      $("dashboard").classList.add("hidden"); $("welcome").classList.remove("hidden"); $("logoutBtn").classList.add("hidden");
    }
  });
}
