# Keshan Money — starter project

A responsive neon rewards UI with Firebase Google/Facebook sign-in and a demo dashboard.

## Included
- Mobile-responsive HTML/CSS UI with coin animation.
- Google and Facebook Firebase Authentication hooks.
- Demo-only daily bonus, sample task points and referral-link UI.
- Firestore rules that block client writes to balances and admin-owned records.
- Starter Cloud Functions for server-side daily bonus and a withdrawal review request.

## Important limitations
This is a starter, not a production cash-earning service. The dashboard's points are demo points only. The demo tasks, referral and daily bonus run only in the browser and reset when the page is reloaded. The Cloud Functions are examples and are not wired to the front-end yet. No ad provider or payout provider is connected. Do not advertise cash earnings or accept payout details until the full backend, fraud controls, policies and legal/payment requirements are completed.

Google AdSense does not permit rewarding users for clicks on ordinary ads. Do not ask users to click ads. Use an ad provider/product that explicitly supports rewarded inventory and follow its terms. An ordinary website ad code is not a rewarded-ad integration.

## 1. Create Firebase project
1. Open https://console.firebase.google.com/ and create a project.
2. Add a Web app and copy its Firebase config.
3. In `app.js`, replace `YOUR_FIREBASE_API_KEY`, `YOUR_PROJECT_ID`, and `YOUR_FIREBASE_APP_ID` with the values from Firebase project settings.
4. Firebase Console → Authentication → Sign-in method: enable Google and Facebook.
5. For Facebook, create/configure a Facebook app, add its App ID and App Secret in Firebase's Facebook provider settings, and add Firebase's OAuth redirect URI in Facebook Login settings.
6. Authentication → Settings → Authorized domains: add your GitHub Pages domain, e.g. `YOURNAME.github.io`.
7. Create a Cloud Firestore database. Publish `firestore.rules`.

Firebase web config is not a server secret, but never commit service-account private keys, Facebook App Secret, or other server secrets to GitHub.

## 2. Run locally
Serve the folder from a local HTTP server (not by opening index.html as a file). For example:
```bash
python -m http.server 8000
```
Open http://localhost:8000. Add `localhost` to Firebase authorized domains if needed.

## 3. Publish with GitHub Pages
1. Create a GitHub repository named `keshan-money`.
2. Upload `index.html`, `style.css`, `app.js`, `firebase.json`, `firestore.rules`, `functions/`, and `README.md`.
3. GitHub repo → Settings → Pages → Deploy from a branch → `main` / root → Save.
4. Wait for the published URL, usually `https://YOURNAME.github.io/keshan-money/`.
5. Add that exact domain (`YOURNAME.github.io`) to Firebase Authentication → Authorized domains.
6. Test Google and Facebook sign-in on the published HTTPS URL.

## 4. Deploy Firestore rules and Cloud Functions
Cloud Functions require the Firebase CLI and may require a billing-enabled Firebase/Google Cloud project depending on current plan and usage.
```bash
npm install -g firebase-tools
firebase login
firebase use --add
firebase deploy --only firestore:rules,functions
```
When prompted, select your Firebase project. In `functions/` run `npm install` if the deploy process does not install dependencies automatically.

## 5. Before real-money launch
- Wire UI buttons to callable Cloud Functions; do not award money/points from browser code.
- Add admin roles using custom claims set only by a trusted server/admin process; never let users set their own role.
- Implement admin-only approval/rejection functions, audit logs, balance holds and idempotent payout processing.
- Add referral fraud prevention, duplicate-account detection, task verification, rate limiting and abuse monitoring.
- Integrate an ad provider whose terms explicitly permit the exact rewarded-ad flow. Reward only after a trusted provider verification callback/server-side validation; do not reward ad clicks.
- Integrate a supported payment provider, validate identity/payout requirements, publish terms/privacy policy and check local legal/tax obligations.
- Add automated tests for Firestore rules and Cloud Functions, and review security before collecting real user data.

## Data model idea
- `users/{uid}`: server-owned points, profile fields and timestamps.
- `ledger/{entryId}`: append-only reward/payout audit records.
- `dailyClaims/{uid_YYYY-MM-DD}`: daily claim uniqueness.
- `withdrawals/{requestId}`: `pending_review`, `approved`, `rejected`, `paid`.
- `referrals/{referralId}`, `tasks/{taskId}`, `adRewards/{rewardId}`: server-verified records.

The included withdrawal function is only a request-queue example. It does not reserve/deduct points or transfer funds and must be hardened before production.
