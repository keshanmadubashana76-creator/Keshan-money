const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { initializeApp } = require("firebase-admin/app");
const { getFirestore, FieldValue } = require("firebase-admin/firestore");

initializeApp();
const db = getFirestore();

function requireUser(request) {
  if (!request.auth) throw new HttpsError("unauthenticated", "Please sign in first.");
  return request.auth.uid;
}

// Example safe daily bonus: server-owned balance and once-per-day claim.
// This function is NOT wired to the UI yet. Deploy and test before connecting it.
exports.claimDailyBonus = onCall(async (request) => {
  const uid = requireUser(request);
  const day = new Date().toISOString().slice(0, 10); // UTC day
  const userRef = db.doc(`users/${uid}`);
  const claimRef = db.doc(`dailyClaims/${uid}_${day}`);
  await db.runTransaction(async tx => {
    const [userSnap, claimSnap] = await Promise.all([tx.get(userRef), tx.get(claimRef)]);
    if (claimSnap.exists) throw new HttpsError("already-exists", "Daily bonus already claimed.");
    const current = userSnap.exists ? Number(userSnap.get("points") || 0) : 0;
    tx.set(userRef, {
      points: current + 10,
      displayName: request.auth.token.name || "Member",
      updatedAt: FieldValue.serverTimestamp()
    }, {merge: true});
    tx.create(claimRef, {uid, day, points: 10, createdAt: FieldValue.serverTimestamp()});
    const ledgerRef = db.collection("ledger").doc();
    tx.set(ledgerRef, {uid, type: "daily_bonus", points: 10, createdAt: FieldValue.serverTimestamp()});
  });
  return {ok: true, pointsAwarded: 10};
});

// Admin review queue. This records a request only; it does not send money.
// Before production, add minimum-balance checks, verified payout details,
// rate limits, idempotency, fraud review, and an admin-only approval function.
exports.requestWithdrawal = onCall(async (request) => {
  const uid = requireUser(request);
  const points = Number(request.data && request.data.points);
  if (!Number.isInteger(points) || points < 1000 || points > 1000000) {
    throw new HttpsError("invalid-argument", "Request must be between 1,000 and 1,000,000 points.");
  }
  const userRef = db.doc(`users/${uid}`);
  const userSnap = await userRef.get();
  if (!userSnap.exists || Number(userSnap.get("points") || 0) < points) {
    throw new HttpsError("failed-precondition", "Insufficient verified points.");
  }
  const ref = await db.collection("withdrawals").add({
    uid, points, status: "pending_review",
    createdAt: FieldValue.serverTimestamp()
  });
  return {ok: true, requestId: ref.id, status: "pending_review"};
});
